# TEO_push
2D Equilibrium Control for Humanoid Robot TEO by Inertial Perception


Instructions:

	1. Terminal 1:	ssh 2.2.2.52 / ssh locomotion

	2. Terminal 1:	yarpdev --subdevice xsensmtx --device inertial --name /inertial --verbose

	3. Terminal 2:	ssh 2.2.2.52 / ssh locomotion

	4. Terminal 2:	launchLocomotion

	5. Launch TEO_push
